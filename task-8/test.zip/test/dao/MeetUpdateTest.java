package dao;

import entity.Event;
import junit.framework.TestCase;
import org.junit.Test;

public class MeetUpdateTest extends TestCase {

        MeetUpdate eetUpdate = new MeetUpdate();
        Event e = new Event("e-877720a","2018-07-06","2018-08-06");
    @Test
    public void testaddEvent() throws Exception {

    }

    @Test
    public void testaddEventTime() throws Exception {
    }
}
