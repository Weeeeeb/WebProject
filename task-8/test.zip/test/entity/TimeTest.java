package entity;

import junit.framework.TestCase;
import org.junit.Test;

public class TimeTest extends TestCase {
    Time time = new Time();
    String eventID = "e-877720N";
    String date = "2018-07-08";
    String startT = "9";
    String endT = "17";
    Time time1 = new Time("e-877721N","2018-07-09","8","16");
    @Test
    public void testgetStartT() throws Exception {
        time.setStartT(startT);
        assertEquals("9",time.getStartT());
        assertEquals("8",time1.getStartT());
    }

    @Test
    public void testsetStartT() throws Exception {
    }

    @Test
    public void testgetEndT() throws Exception {
        time.setEndT(endT);
        assertEquals("17",time.getEndT());
        assertEquals("16",time1.getEndT());
    }

    @Test
    public void testsetEndT() throws Exception {
    }

    @Test
    public void testgetDate() throws Exception {
        time.setDate(date);
        assertEquals("2018-07-08",time.getDate());
        assertEquals("2018-07-09",time1.getDate());
    }

    @Test
    public void testsetDate() throws Exception {
    }

    @Test
    public void testgetEventID() throws Exception {
        time.setEventID(eventID);
        assertEquals("e-877720N",time.getEventID());
        assertEquals("e-877721N",time1.getEventID());
    }

    @Test
    public void testsetEventID() throws Exception {
    }

    @Test
    public void testgetMonthandDate() throws Exception {
    }

    @Test
    public void testgetDay() throws Exception {
    }

}
