package dao;

import junit.framework.TestCase;
import org.junit.Test;

public class SmallTimeDealTest extends TestCase {
    @Test
    public void testgetSlotsOfEvent() throws Exception {
    }

    @Test
    public void testaddSmallTime() throws Exception {
    }

    @Test
    public void testsmallTimeIsExist() throws Exception {
    }

    @Test
    public void testupdateSmallTime() throws Exception {
    }

    @Test
    public void testmodifySmallTime() throws Exception {
    }

}
