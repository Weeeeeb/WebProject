package db;

import junit.framework.TestCase;
import org.junit.Test;

public class sqlHelperTest extends TestCase {
    @Test
    public void testquery() throws Exception {
    }

    @Test
    public void testupdate() throws Exception {
    }

}
