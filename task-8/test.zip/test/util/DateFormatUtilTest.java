package util;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Date;

public class DateFormatUtilTest extends TestCase {
    DateFormatUtil dateFormatUtil = new DateFormatUtil();
    Date date = new Date();

    @Test
    public void testgetTimes() throws Exception {
        assertEquals(1532057940,dateFormatUtil.getTimes(10,11,39));
    }

    @Test
    public void testgetIntegralTime() throws Exception {
    }

    @Test
    public void testgetIntegralTimeEnd() throws Exception {
        assertEquals(1531238400,dateFormatUtil.getIntegralTimeEnd());
    }

    @Test
    public void testtransForDate3() throws Exception {
    }

    @Test
    public void testtransForDate1() throws Exception {
        assertEquals("2018-07-20 11:39:00",dateFormatUtil.transForDate1(1532057940));
    }

    @Test
    public void testtransForDate11() throws Exception {
    }

    @Test
    public void testtransForDate2() throws Exception {
        assertEquals("2018-07-20",dateFormatUtil.transForDate2(1532057940));
    }

    @Test
    public void testtransForDate4() throws Exception {
        assertEquals("2018.07.20",dateFormatUtil.transForDate4(1532057940));
    }

    @Test
    public void testtransForDate5() throws Exception {
        assertEquals("2018/07/20 11:39:00",dateFormatUtil.transForDate5(1532057940));
    }

    @Test
    public void testtransForDateInChinese() throws Exception {
        assertEquals("2018年07月20日 11:39:00",dateFormatUtil.transForDateInChinese(1532057940));
    }

    @Test
    public void testtransForMilliSecond() throws Exception {
    }

    @Test
    public void testcurrentTimeStamp() throws Exception {
    }

    @Test
    public void testtransForMilliSecond1() throws Exception {
    }

    @Test
    public void testtransForMilliSecond2() throws Exception {
    }

    @Test
    public void testtransForMilliSecondByTim() throws Exception {
    }

    @Test
    public void testformatDate() throws Exception {
    }

    @Test
    public void testformatDate1() throws Exception {
    }

    @Test
    public void testformatDate2() throws Exception {
    }

    @Test
    public void testformatDate3() throws Exception {
    }

    @Test
    public void testtransForDate() throws Exception {
        assertEquals("2018-07-20 11:39:00",dateFormatUtil.transForDate(1532057940,"yyyy-MM-dd HH:mm:ss"));
    }

    @Test
    public void testsplitBigDecimal() throws Exception {
    }

    @Test
    public void testcaculate2Days() throws Exception {
    }

    @Test
    public void testsumBigDicimal() throws Exception {
    }

    @Test
    public void testsumBigDicimalAndDouble() throws Exception {
    }

    @Test
    public void testsubBigDicimal() throws Exception {
    }

    @Test
    public void testgetTimediff() throws Exception {
    }

    @Test
    public void testweekFirstDay() throws Exception {
        assertEquals("2018-07-09 00:00:00",dateFormatUtil.weekFirstDay(0));
    }

    @Test
    public void testaddYear() throws Exception {
        assertEquals("2019-07-20 11:39:00",dateFormatUtil.addYear(1532057940));
    }

    @Test
    public void testweekLastDay() throws Exception {
        assertEquals("2018-07-15 23:59:59",dateFormatUtil.weekLastDay(0));
    }

    @Test
    public void testgreaterThanNow() throws Exception {
    }

    @Test
    public void testtransFromTime() throws Exception {
    }

    @Test
    public void testtransToTime() throws Exception {
    }

    @Test
    public void testtransToChuo() throws Exception {
    }
}
