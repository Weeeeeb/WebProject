package util;

import junit.framework.TestCase;
import org.junit.Test;

public class Date_StampTest extends TestCase {
    Date_Stamp date_stamp = new Date_Stamp();
    @Test
    public void testgetYMDDates() throws Exception {
        assertEquals("2018-07-10",date_stamp.getYMDDates("2"));
    }

    @Test
    public void teststrToStamp() throws Exception {
        assertEquals(1531152000,date_stamp.StrToStamp("2018-07-10"));
    }

    @Test
    public void testgetTimes() throws Exception {
        assertEquals(1531193940,date_stamp.getTimes(2018,07,10,11,39));
    }

    @Test
    public void testtransForDate() throws Exception {
    }

    @Test
    public void testtransForDateToStr() throws Exception {
        assertEquals("2018-07-10-11-39-00",date_stamp.transForDateToStr(1531193940));
    }

    @Test
    public void testformatDate() throws Exception {
    }
}
