package db;

import junit.framework.TestCase;
import org.junit.Test;
public class JDBCUtilTest extends TestCase {
    @Test
    public void testgetConnection() throws Exception {
    }

    @Test
    public void testcloseConn() throws Exception {
    }

}
