package service;

import junit.framework.TestCase;
import org.junit.Test;

public class ServiceFactoryTest extends TestCase {
    @Test
    public void testgetInstance() throws Exception {
    }

    @Test
    public void testgetDealUser() throws Exception {
    }

    @Test
    public void testcloseDealUser() throws Exception {
    }

    @Test
    public void testgetAddEvent() throws Exception {
    }

    @Test
    public void testcloseAddEvent() throws Exception {
    }

    @Test
    public void testgetDealSmallTime() throws Exception {
    }

    @Test
    public void testcloseDealSmallTime() throws Exception {
    }

    @Test
    public void testgetQueryEvent() throws Exception {
    }

    @Test
    public void testcloseQueryEvent() throws Exception {
    }
}
