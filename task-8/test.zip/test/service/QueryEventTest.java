package service;

import junit.framework.TestCase;
import org.junit.Test;

public class QueryEventTest extends TestCase {
    @Test
    public void testgetEvent() throws Exception {
    }

    @Test
    public void testgetTime() throws Exception {
    }

}
