package entity;

import junit.framework.TestCase;
import org.junit.Test;

public class TimeDealUtilTest extends TestCase {
    String str = "2018-07-08";
    @Test
    public void testgetMonth() throws Exception {
        assertEquals("Jul",new TimeDealUtil().getMonth(str));
    }

    @Test
    public void testgetDate() throws Exception {
        assertEquals("8",new TimeDealUtil().getDate(str));
    }

    @Test
    public void testgetDay() throws Exception {
        assertEquals("Sun",new TimeDealUtil().getDay(str));
    }

}
