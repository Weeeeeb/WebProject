package entity;

import junit.framework.TestCase;
import org.junit.Test;

public class SmallTimeTest extends TestCase {
    SmallTime smallTime = new SmallTime();
    SmallTime smallTime1 = new SmallTime(8,16);
    int startT = 9;
    int endT = 17;
    @Test
    public void testgetStartT() throws Exception {
        smallTime.setStartT(startT);
        assertEquals(9,smallTime.getStartT());
        assertEquals(8,smallTime1.getStartT());
    }

    @Test
    public void testsetStartT() throws Exception {
    }

    @Test
    public void testgetEndT() throws Exception {
        smallTime.setEndT(endT);
        assertEquals(17,smallTime.getEndT());
        assertEquals(16,smallTime1.getEndT());
    }

    @Test
    public void testsetEndT() throws Exception {
    }

}
