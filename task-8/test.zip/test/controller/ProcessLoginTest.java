package controller;

import junit.framework.TestCase;
import org.junit.Test;

public class ProcessLoginTest extends TestCase {
    @Test
    public void doGet() throws Exception {
    }

    @Test
    public void doPost() throws Exception {
    }

    @Test
    public void testdoGet() throws Exception {
    }

    @Test
    public void testdoPost() throws Exception {
    }

}
