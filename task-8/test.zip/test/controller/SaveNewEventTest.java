package controller;

import junit.framework.TestCase;
import org.junit.Test;
public class SaveNewEventTest extends TestCase {
    @Test
    public void testdoGet() throws Exception {
    }

    @Test
    public void testdoPost() throws Exception {
    }
}
