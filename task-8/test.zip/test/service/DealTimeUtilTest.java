package service;

import junit.framework.TestCase;
import org.junit.Test;

public class DealTimeUtilTest extends TestCase {
    @Test
    public void testdealTime() throws Exception {
    }

    @Test
    public void testprintTime() throws Exception {
    }

    @Test
    public void testsmallInterval() throws Exception {
    }

    @Test
    public void testprintSmallTime() throws Exception {
    }

}
