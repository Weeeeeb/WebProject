package service;

import junit.framework.TestCase;
import org.junit.Test;

public class AddEventTest extends TestCase {
    AddEvent addEvent = new AddEvent();
    @Test
    public void testaddNewEvent() throws Exception {
    }

    @Test
    public void testaddEventTime() throws Exception {
    }

    @Test
    public void testgetNowDate() throws Exception {
        assertEquals("2018-07-10",addEvent.getNowDate());
    }

    @Test
    public void testgetNextDate() throws Exception {
        assertEquals("2018-08-10",addEvent.getNextDate());
    }

}
