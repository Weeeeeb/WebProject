package service;

import junit.framework.TestCase;
import org.junit.Test;

public class CreateOnlyIDTest extends TestCase {
    CreateOnlyID createOnlyID = new CreateOnlyID();
    @Test
    public void testonlyUserID() throws Exception {
    }

    @Test
    public void testonlyEventID() throws Exception {
    }

    @Test
    public void testgetNowDate() throws Exception {
        assertEquals("2018-07-10",createOnlyID.getNowDate());
    }

    @Test
    public void testgetNextDate() throws Exception {
        assertEquals("2018-08-10",createOnlyID.getNextDate());
    }

}
