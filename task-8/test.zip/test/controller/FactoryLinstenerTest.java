package controller;

import junit.framework.TestCase;
import org.junit.Test;

import javax.servlet.ServletContextEvent;

public class FactoryLinstenerTest extends TestCase{
    @Test
    public void testcontextInitialized() throws Exception {
    }

    @Test
    public void testcontextDestroyed() throws Exception {
    }


}
