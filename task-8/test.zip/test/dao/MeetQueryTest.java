package dao;

import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;

public class MeetQueryTest extends TestCase {
    @Test
    public void testqueryEvent() throws Exception {
    }

    @Test
    public void testqueryTime() throws Exception {
    }
}
