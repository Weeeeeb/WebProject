package dao;

import junit.framework.TestCase;;
import org.junit.Test;

public class UserOperatorTest extends TestCase {
    @Test
    public void testqueryUser() throws Exception {
    }

    @Test
    public void testgetUsersOfEvent() throws Exception {
    }

    @Test
    public void testqueryUserExist() throws Exception {
    }

    @Test
    public void testqueryUserIsTrue() throws Exception {
    }

    @Test
    public void testaddUser() throws Exception {
    }

    @Test
    public void testuserLoginIsOk() throws Exception {
    }

}
