package service;

import junit.framework.TestCase;
import org.junit.Test;


public class DealUserTest extends TestCase {
    DealUser user = new DealUser();
    @Test
    public void testuserLogin() throws Exception {
        assertEquals(true,user.userLogin("1045595","wangdan","wd","e-877720N"));
        assertEquals(true, user.userLogin("1045595","wangdan","","e-877720N"));
    }

    @Test
    public void testgetUsers() throws Exception {
    }

    @Test
    public void testgetUsers1() throws Exception {
    }

}
