package util;

import junit.framework.TestCase;
import org.junit.Test;

public class MD5Test extends TestCase {
    MD5 md5 = new MD5();
    @Test
    public void testmd5() throws Exception {
        assertEquals("ad57484016654da87125db86f4227ea3",md5.md5("ww"));
    }

}
