package entity;

import junit.framework.TestCase;
import org.junit.Test;

public class EventTest extends TestCase {
    Event event = new Event();
    Event event1 = new Event("e-877721N","2018-07-08","2018-08-08");
    @Test
    public void testgetZone() throws Exception {
        event.setZone("Asia/Shanghai");
        assertEquals("Asia/Shanghai",event.getZone());
    }

    @Test
    public void testsetZone() throws Exception {
    }

    @Test
    public void testgetEventName() throws Exception {
        event.setEventName("new event");
        assertEquals("new event",event.getEventName());
    }

    @Test
    public void testsetEventName() throws Exception {
    }

    @Test
    public void testgetEventID() throws Exception {
        event.setEventID("e-877720N");
        assertEquals("e-877720N",event.getEventID());
        assertEquals("e-877721N",event1.getEventID());
    }

    @Test
    public void testsetEventID() throws Exception {
    }

    @Test
    public void testgetCreateTime() throws Exception {
        event.setCreateTime("2018-07-09");
        assertEquals("2018-07-09",event.getCreateTime());
        assertEquals("2018-07-08",event1.getCreateTime());
    }

    @Test
    public void testsetCreateTime() throws Exception {
    }

    @Test
    public void testgetDelTime() throws Exception {
        event.setDelTime("2018-08-09");
        assertEquals("2018-08-09",event.getDelTime());
        assertEquals("2018-08-08",event1.getDelTime());
    }

    @Test
    public void testsetDelTime() throws Exception {
    }

}
