package dao;

import junit.framework.TestCase;
import org.junit.Test;

public class DaoFactoryTest extends TestCase {
    @Test
    public void testgetInstance() throws Exception {
    }

    @Test
    public void testgetSmallTimeDeal() throws Exception {
    }

    @Test
    public void testcloseSmallTimeDeal() throws Exception {
    }

    @Test
    public void testgetMeetQuery() throws Exception {
    }

    @Test
    public void testcloseMeetQuery() throws Exception {
    }

    @Test
    public void testgetMeetUpdate() throws Exception {
    }

    @Test
    public void testcloseMeetUpdate() throws Exception {
    }

    @Test
    public void testgetUserOperator() throws Exception {
    }

    @Test
    public void testcloseUserOperator() throws Exception {
    }
}
