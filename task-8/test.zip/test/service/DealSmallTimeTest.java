package service;

import junit.framework.TestCase;
import org.junit.Test;

public class DealSmallTimeTest extends TestCase {
    @Test
    public void testupdateSmall() throws Exception {
    }

    @Test
    public void testgetSmallSlots() throws Exception {
    }

}
