package service;

import junit.framework.TestCase;
import org.junit.Test;

public class DealSlotsTest extends TestCase {
    @Test
    public void testgetAllSlots() throws Exception {
    }

}
