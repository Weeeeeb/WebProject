package entity;

import junit.framework.TestCase;
import org.junit.Test;

public class SlotsTest extends TestCase {
    Slots slots = new Slots();
    Slots slots1 = new Slots(6,"1045595");
    @Test
    public void testgetIndex() throws Exception {
        slots.setIndex(7);
        assertEquals(7,slots.getIndex());
        assertEquals(6,slots1.getIndex());
    }

    @Test
    public void testsetIndex() throws Exception {
    }

    @Test
    public void testgetUserID() throws Exception {
        slots.setUserID("1045596");
        assertEquals("1045596",slots.getUserID());
        assertEquals("1045595",slots1.getUserID());
    }

    @Test
    public void testsetUserID() throws Exception {
    }

}
