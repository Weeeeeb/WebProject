package entity;

import junit.framework.TestCase;
import org.junit.Test;

public class UserTest extends TestCase {
    User user = new User();
    String userID = "1045590";
    String userName = "wangdan";
    String eventID = "e-877729N";
    User user1 = new User("1045596","wd","123","e-877721N");
    @Test
    public void testgetUserID() throws Exception {
        user.setUserID(userID);
        assertEquals("1045590",user.getUserID());
        assertEquals("1045596",user1.getUserID());
    }

    @Test
    public void testsetUserID() throws Exception {
    }

    @Test
    public void testgetPassword() throws Exception {
        assertEquals("123",user1.getPassword());
    }

    @Test
    public void testsetPassword() throws Exception {
    }

    @Test
    public void testgetEventID() throws Exception {
        user.setEventID(eventID);
        assertEquals("e-877729N",user.getEventID());
        assertEquals("e-877721N",user1.getEventID());
    }

    @Test
    public void testsetEventID() throws Exception {
    }

    @Test
    public void testgetUserName() throws Exception {
        user.setUserName(userName);
        assertEquals("wangdan",user.getUserName());
        assertEquals("wd",user1.getUserName());
    }

    @Test
    public void testsetUserName() throws Exception {
    }

}
