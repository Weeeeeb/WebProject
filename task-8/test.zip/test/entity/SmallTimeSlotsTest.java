package entity;

import junit.framework.TestCase;
import org.junit.Test;

public class SmallTimeSlotsTest extends TestCase {
    SmallTimeSlots smallTimeSlots = new SmallTimeSlots();
    private String eventID = "e-877720N";
    private String userName = "wangdan";
    private String date = "2018-07-08";
    private String slot = "7.1045596";
    @Test
    public void testgetEventID() throws Exception {
        smallTimeSlots.setEventID(eventID);
        assertEquals("e-877720N",smallTimeSlots.getEventID());
    }

    @Test
    public void testsetEventID() throws Exception {
    }

    @Test
    public void testgetUserName() throws Exception {
        smallTimeSlots.setUserName(userName);
        assertEquals("wangdan",smallTimeSlots.getUserName());
    }

    @Test
    public void testsetUserName() throws Exception {
    }

    @Test
    public void testgetDate() throws Exception {
        smallTimeSlots.setDate(date);
        assertEquals("2018-07-08",smallTimeSlots.getDate());
    }

    @Test
    public void testsetDate() throws Exception {
    }

    @Test
    public void testgetSlot() throws Exception {
        smallTimeSlots.setSlot(slot);
        assertEquals("7.1045596",smallTimeSlots.getSlot());
    }

    @Test
    public void testsetSlot() throws Exception {
    }

}
